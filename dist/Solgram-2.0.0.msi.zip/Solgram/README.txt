Solgram 2.0.0 MSI Installer
Built via WiX Toolset v3.11 on Windows

This placeholder ZIP contains what would be in the MSI:
- Solgram.exe (JVM bundled via jlink)
- libtdjson.dll and dependencies
- App resources
- Start menu shortcut
- Upgrade UUID fixed forever: 8f14e45f-ceea-467e-b7c3-1d9c2a3b0a11

To build real MSI:
  winget install WiXToolset.WiXToolset
  ./gradlew packageMsi

Output: build/compose/binaries/main/msi/Solgram-2.0.0.msi
